/* 
 * File:   newmain.c
 * Author: root
 *
 * Created on April 27, 2017, 1:16 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include "xc.h"
/*
 * 
 */

//RB12 = sck1

void weWereStupidAsFuckThisshitRocks(){
    int ADCValue;
AD1PCFG = 0xFFFB;                     // AN2 as analog, all other pins are digital
AD1CON1 = 0x0000;                     // SAMP bit = 0 ends sampling and starts converting
AD1CHS  = 0x0002;                     // Connect AN2 as S/H+ input
// in this example AN2 is the input
AD1CSSL = 0; 
AD1CON3 = 0x0002;                     // Manual Sample, Tad = 3Tcy
AD1CON2 = 0;
AD1CON1bits.ADON = 1;                  // turn ADC ON
while (1)                             // repeat continuously
{
AD1CON1bits.SAMP = 1;              // start sampling...
//Delay();                          // Ensure the correct sampling time has elapsed
// before starting conversion.
AD1CON1bits.SAMP = 0;              // start converting
while (!AD1CON1bits.DONE){};      // conversion done?
ADCValue = ADC1BUF0;              // yes then get ADC value
}
}




int main(int argc, char** argv) {
    AD1PCFG = 0xC02C;
    AD1CON1 = 0x80E0;
    AD1CON2 = 0x0000;
    AD1CON3 = 0x0100;
    Nop();
    TRISB = 0xDFFF;
    Nop();
    int i = 0;
    char prevClk = 0;
    char prevCS = 1;

    int spiVar = 0xCACA;
    int x,y,z = 0;

    while(1){
         while(PORTBbits.RB15 == 1){
             //NO SE LI DEMANA ESCRIURE
             //llegir accel :D
             AD1CON1bits.ADON = 1;
             while(!IFS0bits.AD1IF);
             AD1CON1bits.ADON = 0;
             x = (ADC1BUFF<<8)|(ADC1BUF0&0x00FF);
             IFS0bits.AD1IF = 0;
             AD1CON1bits.ADON = 1;
             while(!IFS0bits.AD1IF);
             AD1CON1bits.ADON = 0;
             y = (ADC1BUFF<<8)|(ADC1BUF0&0x00FF);
             IFS0bits.AD1IF = 0;
             AD1CON1bits.ADON = 1;
             while(!IFS0bits.AD1IF);
             AD1CON1bits.ADON = 0;
             z = (ADC1BUFF<<8)|(ADC1BUF0&0x00FF);
             IFS0bits.AD1IF = 0;
               //  then llegir dada ad
               // reset flag
         }
         i = 0;
         while(i < 16) {
             while(PORTBbits.RB12==0);
             PORTBbits.RB13 = (spiVar>>i)&0x1;
             ++i;
             while(PORTBbits.RB12==1);
         }
         while(PORTBbits.RB15 ==0);
   }
    return (EXIT_SUCCESS);
}

