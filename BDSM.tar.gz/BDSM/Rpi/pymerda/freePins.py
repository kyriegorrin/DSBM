import RPi.GPIO as GPIO

GPIO.cleanup()
print("Shenanigans cleaned")
