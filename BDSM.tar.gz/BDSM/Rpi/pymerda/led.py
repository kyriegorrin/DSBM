import RPi.GPIO as GPIO
import time
import signal
import sys

def run_program():
	GPIO.setmode(GPIO.BOARD)
	GPIO.setup(7,GPIO.OUT)
	while 1:
		GPIO.output(7,GPIO.HIGH)
		time.sleep(1)	
		GPIO.output(7,GPIO.LOW)
		time.sleep(1)
def exit_gracefully(signum, frame):
	signal.signal(signal.SIGINT, original_sigint)
	GPIO.cleanup()
	sys.exit(1)
	signal.signal(signal.SIGINT, exit_gracefully)
if __name__ == '__main__':
        original_sigint = signal.getsignal(signal.SIGINT)
	signal.signal(signal.SIGINT, exit_gracefully)
	run_program()
