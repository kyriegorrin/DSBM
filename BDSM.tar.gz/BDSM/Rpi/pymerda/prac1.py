import RPi.GPIO as GPIO
import time
import math

GPIO.setmode(GPIO.BOARD)
GPIO.setup(7,GPIO.OUT)
GPIO.setup(11,GPIO.IN)

def discharge_cap():
	GPIO.output(7,GPIO.LOW)
	time.sleep(0.1)

def calculaVolts(t):
	volts = 3.3*(1-math.exp(-t/(0.0000001*220)))
	print(volts)

def read_cap():
	while 1:
		discharge_cap()
		timeNow = time.time()
		GPIO.output(7, GPIO.HIGH)
		while GPIO.input(11) == 0:
			pass
			
		timeAfter = time.time()
#		print(timeAfter - timeNow)
		#calculaVolts(timeAfter-timeNow)

if __name__ == "__main__":
	discharge_cap()
	read_cap()
	GPIO.cleanup()	
