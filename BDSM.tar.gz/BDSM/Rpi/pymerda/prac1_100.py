import RPi.GPIO as GPIO
import time
import math

GPIO.setmode(GPIO.BOARD)
GPIO.setup(7,GPIO.OUT)
GPIO.setup(11,GPIO.IN)

def discharge_cap():
	GPIO.output(7,GPIO.LOW)
	time.sleep(0.1)

def calculaVolts(t):
	volts = 3.3*(1-math.exp(-t/(0.0000001*220)))
	print(volts)

def vomitaStats(mesures):
	#Mitjana
	sumaValors = 0

	for i in range (100):
		sumaValors += mesures[i]
	mitjana = sumaValors/100
	print("MITJANA:")
	print(mitjana)

	#Desviat estandar
	sumaRara = 0
	for i in range (100):
		sumaRara += math.pow(mesures[i] - mitjana,2)
	sumaRara = sumaRara/100
	desviacio = math.sqrt(sumaRara)
	print("DESVIAT ESTANDAR")
	print(desviacio)

	#Bits significatius TODO

def read_cap():
	mesures = []

	for e in range (100):
		mesures.append(0)
	
	for i in range (100):
		discharge_cap()
		timeNow = time.time()
		GPIO.output(7, GPIO.HIGH)
		while GPIO.input(11) == 0:
			pass
			
		timeAfter = time.time()
		mesures[i] = 1000*(timeAfter-timeNow)
		#print(mesures[i])
		#print(i)
		#calculaVolts(timeAfter-timeNow)

	vomitaStats(mesures)
		
if __name__ == "__main__":
	discharge_cap()
	read_cap()
	GPIO.cleanup()	
