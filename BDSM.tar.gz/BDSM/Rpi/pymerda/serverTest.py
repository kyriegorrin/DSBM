#!/usr/bin/env python
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BOARD)
GPIO.setup(36,GPIO.OUT)
GPIO.setup(35,GPIO.IN)
while True:
  GPIO.output(36,0)
  time.sleep(0.1)
  startTime = time.time()
  GPIO.output(36,1)
  while GPIO.input(35) == 0:
    pass
  timeElapsed = (time.time() - startTime) *1000
  with open('/var/www/server.txt', 'w') as f:
    f.write('The capacitor is charged in: {0} ms'.format(timeElapsed))
GPIO.cleanup()
                      