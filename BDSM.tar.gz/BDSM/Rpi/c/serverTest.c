#include <wiringPi.h>
#include <sys/time.h>
#include <stdio.h>



float timedifference_msec(struct timeval t0, struct timeval t1){
    return (t1.tv_sec - t0.tv_sec) * 1000.0f + (t1.tv_usec - t0.tv_usec) / 1000.0f;
}


int main (void){
    wiringPiSetupPhys();
    pinMode (37, OUTPUT);
    pinMode (35, INPUT);
    struct timeval startT;
    struct timeval endT;
    float elapsed;
    FILE *fp;
    while(1){
      digitalWrite(37, LOW);
      delay(500);
      gettimeofday(&startT, 0);
      digitalWrite(37, HIGH);
      while(digitalRead(35) == 0){}//printf("nel bucleee\n");}
      gettimeofday(&endT, 0);
      elapsed = timedifference_msec(startT, endT);
      printf("time is %.9f ms! \n", elapsed);
      fp = fopen("/var/www/server.txt", "w");
      if(fp == NULL) return -1;
      fprintf(fp, "The capacitor is charged in: %.9f ms", elapsed);
      fclose(fp); 
    }
    return 0;
}
