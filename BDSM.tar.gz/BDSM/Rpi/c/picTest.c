#include "spiLib.h"
#include <stdio.h>

int main (void){
    setupSPI();
    while(1){
		delay(1);
		int x,y,z;
		lecturaPIC(&x,&y,&z);
        printf("Els valors del PIC son:\n  %04x - %04x -  %04x\n",x,y,z);
    }    
}
