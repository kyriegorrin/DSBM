#include "spiLib.h"
#include <stdio.h>

int main (void){
    setupSPI();
    while(1){
      printf("estas tocant a : %d x, %d y \n", xRead(), yRead());
     }    
}
