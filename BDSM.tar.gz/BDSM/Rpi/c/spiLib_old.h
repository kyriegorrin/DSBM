#include <wiringPi.h>
#include <stdio.h>

#define mosi 13
#define miso 11
#define clk 15
#define ss 22

float clkTime = 10;

//time == periode del clk en ms
void setClkTime(float time){
    clkTime = time;
}

void setupSPI(){
  wiringPiSetupPhys();
  pinMode(mosi, OUTPUT);
  pinMode(miso, INPUT);
  pinMode(clk, OUTPUT);
  pinMode(ss, OUTPUT);
  digitalWrite(clk, LOW);
  digitalWrite(ss, HIGH);
}

inline void clkWrite(char value){
  delay(clkTime/2);
  digitalWrite(clk, LOW);
  if(value & 0x01) digitalWrite(mosi, HIGH);
  else digitalWrite(mosi, LOW);
  delay(clkTime/2);
  digitalWrite(clk, HIGH);
}

inline char clkRead(){
  delay(clkTime/2);
  digitalWrite(clk, LOW);
  delay(clkTime/2);
  digitalWrite(clk, HIGH);
  return digitalRead(miso);
}

void setupADC(char channel){
  digitalWrite(ss, LOW);
  clkWrite(1);
  clkWrite(1);
  clkWrite(channel>> 2);
  clkWrite(channel>> 1);
  clkWrite(channel);
}

int adcRead(){
  int i, value;
  for (i = 0; i < 12; ++i){
    value = (value << 1) | (clkRead() & 0x01);
  }
  digitalWrite(ss, HIGH);
  delay(clkTime/2);
  digitalWrite(clk, LOW);
  delay(clkTime/2);
  digitalWrite(clk, HIGH);
  return value;
}

int lecturaADC(unsigned char channel){
  setupADC(channel);
  int i;
  for (i =0; i < 2; ++i){
    delay(clkTime/2);
    digitalWrite(clk, LOW);
    delay(clkTime/2);
    digitalWrite(clk, HIGH);
  }
  return adcRead(); 
}

