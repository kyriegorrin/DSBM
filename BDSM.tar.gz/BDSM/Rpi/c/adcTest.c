#include "spiLib.h"
#include <stdio.h>

int main (void){
    setupSPI();
    while(1){
        printf("El valor del accelerometre es: %d x %d y\n", lecturaADC(0), lecturaADC(1));
    }    
}
