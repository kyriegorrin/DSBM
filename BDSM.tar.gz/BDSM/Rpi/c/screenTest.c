#include "spiLib.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main (void){
    setupSPI();
    SPI_TFT_Reset();
    int x, y;
    for (x = 0; x < 240; ++x){
      for(y = 0; y < 320; ++y){
        SPI_TFT_pixel(x,y, 0xFFFF);
      }
    }
    unsigned char word[13] = "HELLO WORLD!";
    SPI_TFT_string(10,10,&word[0], strlen(word));    
    unsigned char countM[20] = "anem a contar!";
    SPI_TFT_string(12,12, &countM[0], strlen(countM));
    unsigned char ichar = '0';
		int xVal, yVal;
		unsigned char valBuff[5];
   	while(1){
      for (ichar = '0'; ichar <= '9'; ++ichar){
				xVal = xRead();
				yVal = yRead();
        SPI_TFT_character(14,14,ichar);
				
				strcpy(valBuff ,"     ");
				SPI_TFT_string(20,10, &valBuff[0], strlen(valBuff));
				snprintf(valBuff, 10, "%d", xVal);
				SPI_TFT_string(20,10, &valBuff[0], strlen(valBuff));
				strcpy(valBuff ,"     ");
				SPI_TFT_string(22,10, &valBuff[0], strlen(valBuff));
				snprintf(valBuff, 10, "%d", yVal);
				SPI_TFT_string(22,10, &valBuff[0], strlen(valBuff));
        delay(500);
      }
		//	printf("estas tocant a : %d x, %d y \n", xRead(), yRead());
    }

}
