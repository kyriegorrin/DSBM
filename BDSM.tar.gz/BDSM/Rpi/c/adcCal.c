#include "spiLib.h"
#include <stdio.h>

int main (void){
    printf("set \n");
    setupSPI();
    printf("setdone \n");
    while(1){
//        printf("cal time");
        calibrarADC();      
    }    
}
