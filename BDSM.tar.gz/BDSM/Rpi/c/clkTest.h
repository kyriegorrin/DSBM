#include <wiringPi.h>

int main(){
  
}